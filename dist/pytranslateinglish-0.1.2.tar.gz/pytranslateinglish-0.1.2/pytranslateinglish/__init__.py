from .translator import PyTranslateInglish

__all__ = ["PyTranslateInglish"] 